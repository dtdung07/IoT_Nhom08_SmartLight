const admin = require('firebase-admin');
// import admin from 'firebase-admin';
const cron = require('node-cron');

// Khởi tạo Firebase Admin SDK
const serviceAccount = require('./serviceAccountKey.json');

admin.initializeApp({
  credential: admin.credential.cert(serviceAccount),
  databaseURL: 'https://iot-nhom08-default-rtdb.asia-southeast1.firebasedatabase.app'
});

var hour = 0;
var minute = 0;
var state_notification = 1;
var array_tokens = [];
const db = admin.database();
const ref = db.ref('TIME_USE');
const notification = db.ref('TIME_NOTIFICATION');
const tokens_device = db.ref('TIME_NOTIFICATION/tokens_device');

// Lấy thời gian thông báo từ Firebase theo thời gian thực
notification.on('value', (snapshot) => { 
  console.log("Chạy hàm lấy thời gian");
  hour = snapshot.val().time_notification.toString().slice(0, 2);
  minute = snapshot.val().time_notification.toString().slice(3, 5);
  state_notification = snapshot.val().state_notification;
  console.log('Time: ' + hour + ':' + minute);
  startServer();
});

// .once('value', callback) là phương thức bất đồng bộ nên hàm khác sẽ không đợi nó trả về kết quả mà sẽ tiếp tục thực thi luôn

// Lấy danh sách token thiết mobile nhận thông báo
// async function fetchTokens() {
//   const snapshot = await tokens_device.once('value');
//   if (snapshot.exists()) {
//     snapshot.forEach((data) => {
//       array_tokens.push(data.val().token);
//       console.log('Token: ' + data.val().token);
//     });
//   } else {
//     console.log('Không có token nào được lưu trữ!');
//   }
// }

// lấy danh sách token từ firebase theo thời gian thực
tokens_device.on('value',(snapshot)=>{
    console.log("Chạy hàm lấy token");
    array_tokens = [];
    snapshot.forEach((data) => {
        array_tokens.push(data.val().token);
        console.log('Token: ' + data.val().token);
    });
})

// Hàm kiểm tra thiết bị có được dùng trong ngày không
function checkDeviceUsage() {
  const today = new Date().toISOString().split('T')[0]; // Lấy ngày hôm nay ở định dạng YYYY-MM-DD
  ref.limitToLast(1).once('value', (snapshot) => {
    snapshot.forEach((data) => {
      console.log('Date:', data.key);
      console.log('Time:', data.val());
      console.log('Today:', today);

      // Đảm bảo giá trị `data.val()` là số hợp lệ trước khi so sánh
      // == so sánh lỏng lẻo (5 == '5' => true)
      // === so sánh chặt chẽ(phải đúng kiểu dữ liệu) (5 === '5' => false)
      const deviceUsage = parseInt(data.val(), 10) || 0;

      if (data.key.toString() !== today || (data.key.toString() === today && deviceUsage === 0)) {
        console.log('Thiết bị IoT không được sử dụng trong ngày!');
        console.log('Ngày trong Firebase:', data.key);
        console.log('Ngày hôm nay:', today);
        console.log('Số lần sử dụng:', deviceUsage);
        sendNotification();
      } else {
        console.log('Thiết bị IoT đã được sử dụng trong ngày!');
      }
    });
  });
}

// Hàm gửi thông báo
function sendNotification() {
  if (array_tokens.length === 0) {
    console.log('Không có token để gửi thông báo!');
    return;
  }

  console.log('Gửi thông báo: Thiết bị IoT không được sử dụng trong ngày!');
  console.log('Array Tokens: ' + array_tokens);
  const message = {
    notification: {
      title: 'Thông báo sử dụng đèn IoT',
      body: 'Hãy dùng đèn iot',
    },
    tokens: array_tokens // Sửa từ token thành tokens
  };

  admin.messaging().sendEachForMulticast(message)
    .then((response) => {
      console.log('Successfully sent message:', response);
    })
    .catch((error) => {
      console.log('Error sending message:', error);
    });
}

 async function startServer() {
  // Sau khi có token, tiếp tục các tác vụ khác
    // await fetchTokens();
  console.log('Server đang chạy và kiểm tra');
  cron.schedule(`${minute} ${hour} * * *`, () => {
    console.log('Kiểm tra thiết bị IoT...');
    if(state_notification == 1){
      console.log('Gọi hàm kt');
      checkDeviceUsage();
    }else{
      return;
    }
  }, {
    scheduled: true,
    timezone: 'Asia/Ho_Chi_Minh'
  });
}

// Chạy server
// startServer();